
import 'dart:async';
import 'dart:convert';
import 'dart:io';


import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'clsPositioned.dart';
import 'tagmodel.dart';
import 'package:http/http.dart' as http;





void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'main',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: MyHomePage(title: 'MainTest'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}): super(key:key);

  final String title;
  @override
  _MyHomePageState createState() => _MyHomePageState();
  }

class _MyHomePageState extends State<MyHomePage>{

  List<tag_listTodo> _tagList = [];
  List<mainUIList> uiList = [];
  List<String> tags = [];

  Future<bool>? taskReload;

  Timer? _timer;

  Future<void> getTagList() async{
    if(_tagList.length != 0 ) _tagList.clear();
    final routeFromJsonFile = await rootBundle.loadString('assets/jsonFile/tag_list-json.json');
    _tagList = TagList.fromJson(routeFromJsonFile).tag_list ?? <tag_listTodo>[];
  }

  Future<List<tag_listTodo>> get read async {
    List<tag_listTodo> list = [];
    final url = 'http://localhost:3000/users/';
    final uri = Uri.parse(url);
    http.Response response = await http.get(uri);
    if(response.statusCode == 200){
      list = _rawFromJson(response.body);
    }

    return list;
  }

  List<tag_listTodo> _rawFromJson(String str) {
    return List<tag_listTodo>.from(
      json.decode(str).map(
            (x) => tag_listTodo.fromJson(x),
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  void initState(){
    Future.delayed(Duration.zero, () async {
      SetTimer();
    });
    super.initState();
  }

  void SetTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        //taskReload = GetTagList();
        taskReload = GetTagList();
      });
    });
  }

  Future<bool> GetRestful() async{
    _tagList = await read;
    bool checked = false;
    if(_tagList.length != 0)
      checked = true;

    return checked;
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.blue,
                ),
                child: Text("Menu "),
              )
            ],
          ),
        ),
        body: svBody()

    );
  }

  Widget svBody(){
    return
        FutureBuilder(
            future: taskReload,
            builder: (BuildContext context, AsyncSnapshot snapshot){
              if(snapshot.hasData){
                return Stack(
                    clipBehavior: Clip.none,
                    children: <Widget>[
                Container(
                child: Image(
                    image: AssetImage("assets/images/유트론 C.png"),
                    width: 1920,
                    fit: BoxFit.fitHeight,
                    ),
                  ),

                      Setpositioned(tag: GetTag(0),width: 50,height: 30,color: Colors.transparent,text: PositionText(0),textColor: Colors.white,fontSize: 10,left: 1165,top: 428),
                      Setpositioned(tag: GetTag(1),width: 50,height: 30,color: Colors.transparent,text: PositionText(1),textColor: Colors.black,fontSize: 10,left: 350,top: 150),
                      Setpositioned(tag: GetTag(2),width: 50,height: 30,color: Colors.transparent,text: PositionText(2),textColor: Colors.black,fontSize: 10,left: 350,top: 200),
                      Setpositioned(tag: GetTag(3),width: 50,height: 30,color: Colors.transparent,text: PositionText(3),textColor: Colors.white,fontSize: 10,left: 796,top: 813),
                      Setpositioned(tag: GetTag(4),width: 50,height: 30,color: Colors.transparent,text: PositionText(4),textColor: Colors.white,fontSize: 10,left: 943,top: 525),
                      Setpositioned(tag: GetTag(5),width: 50,height: 30,color: Colors.transparent,text: PositionText(5),textColor: Colors.black,fontSize: 10,left: 350,top: 350),
                      Setpositioned(tag: GetTag(6),width: 50,height: 30,color: Colors.transparent,text: PositionText(6),textColor: Colors.black,fontSize: 10,left: 350,top: 400),
                      Setpositioned(tag: GetTag(7),width: 50,height: 30,color: Colors.transparent,text: PositionText(7),textColor: Colors.white,fontSize: 10,left: 895,top: 293),
                      Setpositioned(tag: GetTag(8),width: 50,height: 30,color: Colors.transparent,text: PositionText(8),textColor: Colors.white,fontSize: 10,left: 747,top: 245),
                      Setpositioned(tag: GetTag(9),width: 50,height: 30,color: Colors.transparent,text: PositionText(9),textColor: Colors.white,fontSize: 10,left: 752,top: 378),
                      Setpositioned(tag: GetTag(10),width: 50,height: 30,color: Colors.transparent,text: PositionText(10),textColor: Colors.white,fontSize: 10,left: 834,top: 676),
                      Setpositioned(tag: GetTag(11),width: 50,height: 30,color: Colors.transparent,text: PositionText(11),textColor: Colors.black,fontSize: 10,left: 1350,top: 150),
                      Setpositioned(tag: GetTag(12),width: 50,height: 30,color: Colors.transparent,text: PositionText(12),textColor: Colors.white,fontSize: 10,left: 948,top: 606),
                      Setpositioned(tag: GetTag(13),width: 50,height: 30,color: Colors.transparent,text: PositionText(13),textColor: Colors.white,fontSize: 10,left: 962,top: 453),
                      Setpositioned(tag: GetTag(14),width: 50,height: 30,color: Colors.transparent,text: PositionText(14),textColor: Colors.white,fontSize: 10,left: 1080,top: 277),
                      Column(
               children: [
                 TextButton(onPressed: () {
                   print(PositionText(0));
                 },
                     child: Text("실시간 값 테스트"))
               ],

                      )


                  ],
                );
              }else{
                return Text("");
              }
            });
          }

  String GetTag(int index){
    String tag = '';
    if (tags.length > index)
        tag = tags[index];

    return tag;
  }

  String PositionText(int index) {
    String text = '';
    if(uiList.length > 0){
      var values = uiList[index];

     text = values.tag + '\n' + values.value.toString();

    }
    return text;
  }

 Future<bool> GetTagList() async{
   bool checked = false;
    try{
      _tagList = await read;
     List<mainUIList> _uiList = [];
     if (tags.length != 0) tags.clear();
     if (_tagList.length != 0){
       _tagList.forEach((data) {
         _uiList.add(mainUIList(data.tag, data.value, data.datatime));
         tags.add(data.tag);
       });
     }
     if (_uiList.length != 0){
       uiList.clear();
       uiList = _uiList;
       checked = true;
     }else{
       checked = false;
     }
   }catch(E){
     print(E);
   }
  return checked;
  }
}
















