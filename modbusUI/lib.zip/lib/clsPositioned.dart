

import 'package:flutter/material.dart';

import 'mainchart.dart';

class Setpositioned extends StatefulWidget{
String tag;
Color color;
String text;
Color textColor;
double fontSize;
double left;
double top;
double width;
double height;

Setpositioned({super.key,required this.tag,required this.width,required this.height,required this.color,required this.text,required this.textColor,required this.fontSize,required this.left,required this.top});

@override
State<Setpositioned> createState() => positioned(this.tag,this.width,this.height, this.color, this.text, this.textColor, this.fontSize, this.left, this.top);
}

class positioned extends State<Setpositioned> {
String tag;
Color color;
String text;
Color textColor;
double fontSize;
double left;
double top;
double width;
double height;

positioned( this.tag,this.width,this.height, this.color, this.text, this.textColor, this.fontSize, this.left, this.top);

double _x = 0;
double _y = 0;
double _offsetX = 0;
double _offsetY = 0;

  @override
  Widget build(BuildContext context) {
    return Positioned(
    left: GetXposition(left),
    top: GetYposition(top),
child: GestureDetector(
onPanStart: _onPanStart,
onPanUpdate: _onPanUpdate,
child: svPositionUnit(tag,width,height,color,text,textColor,10),
)
);
  }

void _onPanStart(DragStartDetails details){
print('start(${tag} - x: ${_x}, y: ${_y})   ///  (dx: ${details.globalPosition.dx}, dy: ${details.globalPosition.dy}) ');
_offsetX = _x - details.globalPosition.dx;
_offsetY = _y - details.globalPosition.dy;
}

void _onPanUpdate(DragUpdateDetails details) {
setState(() {
print('update(${tag} - x: ${_x}, y: ${_y})   ///  (dx: ${details.globalPosition.dx}, dy: ${details.globalPosition.dy}) ');
_x = details.globalPosition.dx + _offsetX;
_y = details.globalPosition.dy + _offsetY;
});
}

double GetXposition(position){
double x = 0;
if(_x != 0){
x = _x;
}else{
_x = position;
x = position;
}
return x;
}

double GetYposition(position){
double y = 0;
if(_y != 0){
y = _y;
}else{
_y = position;
y = position;
}
return y;
}

Widget svPositionUnit(tag,width,height,color,text,textColor,fontSize){
return InkWell(
onTap: () {
Navigator.push(context, MaterialPageRoute(
builder: (context) => DataChart(tag)));
},
child: Container(
width: width,
height:height,
child: Text(
    text,
textAlign: TextAlign.center,
style: TextStyle(
color: textColor,
fontSize: fontSize
)
),
decoration: BoxDecoration(
color: color,
border: Border.all(
width: 2,
color: Colors.red
)
)
),
);
}
}