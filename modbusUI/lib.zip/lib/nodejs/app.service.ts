import { Injectable } from '@nestjs/common';

@Injectable()		// 의존성 "주입" 주체가 되도록 등록
export class AppService {
  getHello(): string {
    return 'Hello World!';
  }
}