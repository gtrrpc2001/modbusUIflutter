import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:modbusui/svmain.dart';
import 'package:http/http.dart' as http;
import 'tagmodel.dart';
import 'line_chart.dart';
import 'linechart_data.dart';

class DataChart extends StatelessWidget{


  DataChart(this.tag);
  String tag;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'chart',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: _DataChart(title: 'chartTest',tag: tag),
    );
  }
}

class _DataChart extends StatefulWidget{
  _DataChart({Key? key, required this.title,required this.tag}): super(key:key);

  final String title;
  final String tag;

  @override
  _chart createState() => _chart(tag);

}

class _chart extends State<_DataChart>{
  _chart(this.tag);

  bool _isChecked = true;
  bool _isChecked2 = true;
  String tag;
  Future<bool>? rawReload;
  List<raw_ListTodo> _rawList = [];
  //List<raw_ListTodo> dataList = [];

  Future<bool> GetRawList() async{
    bool checked = false;
    _rawList = await read;
    if (_rawList.length != 0){
      checked = true;
    }
    //print(_rawList.length);
    return checked;
  }



  @override
  void initState(){
    Future.delayed(Duration.zero, () async {
      SetTimer();
    });
    super.initState();
  }

  void SetTimer() {
    Timer(Duration(milliseconds: 100), () {
      setState(() {
        rawReload = GetRawList();
      });
    });
  }

 Future<void> getRawList() async{
   final routeFromJsonFile = await rootBundle.loadString('assets/jsonFile/raw-json.json');
   _rawList = rawList.fromJson(routeFromJsonFile).raw_list ?? <raw_ListTodo>[];

 }

 Future<List<raw_ListTodo>> get read async {
   List<raw_ListTodo> list = [];
    final url = 'http://localhost:3000/raws/one?tag=${tag}';
    final uri = Uri.parse(url);
    final response = await http.get(uri);
    if(response.statusCode == 200)
      list = _rawFromJson(response.body);
    return list;
 }

  List<raw_ListTodo> _rawFromJson(String str) {
    return List<raw_ListTodo>.from(
      json.decode(str).map(
            (x) => raw_ListTodo.fromJson(x),
      ),
    );
  }

  Widget Getfuture(){
   return FutureBuilder(
        future: rawReload,
        builder: (BuildContext context, AsyncSnapshot snapshot){
          List<LineChartBarData> lineChart = [];
          if(snapshot.hasData){
            lineChart = lineChartBarData(_rawList,tag,_isChecked,_isChecked2);
            return Chart(lineChart);
          } else if(snapshot.hasError){
            return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Error: ${snapshot.error}',
                  style: TextStyle(fontSize: 15),
                )
            );
          }else{
            return Text('');
          }
  }
  );
  }

  @override
  Widget build(BuildContext context) {
    //List<LineChartBarData> lineChart = lineChartBarData(_rawList,tag,_isChecked,_isChecked2);
     // Future.delayed(Duration(milliseconds: 500), (){
     //   lineChart = lineChartBarData(_rawList,tag,_isChecked,_isChecked2);
  //});
    return Getfuture();
  }

Widget RawSet(){
    // lineChart = lineChartBarData(_rawList,tag,_isChecked,_isChecked2);
  //print(_rawList.length);
    return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
              children: [
                Checkbox(
                  //key: 2 as Key,
                    value: _isChecked,
                    onChanged: (value) {
                      setState(() {
                        _isChecked = value!;
                      });
                    }
                ),
                Text('row1'),
              ]
          ),
          Row(
              children: [
                Checkbox(
                  //key: 2 as Key,
                    value: _isChecked2,
                    onChanged: (value) {
                      setState(() {
                        _isChecked2 = value!;
                      });
                    }
                ),
                Text('row2'),
              ]
          ),
          Row(
              children: [
                Checkbox(
                    value: _isChecked2,
                    onChanged: (value) {
                      setState(() {

                      });
                    })
              ]
          )
        ]
    );
}

 double FindMaxValue(){
    double maxValue = _rawList.map((e) => e.value).reduce(max);
    return maxValue;
 }

  Widget Chart(lineChart){

      return Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
        ),
        body: Container(
          color: Color(0xfff0f0f0),
          child: ListView(
            padding: EdgeInsets.fromLTRB(0, 30, 0, 30),
            children: <Widget>[
             // SetFuture(),
              ChartContainer(
                title: 'Line Chart',
                color: Color.fromRGBO(45, 108, 223, 1),
                chart: LineChartContent(lineChart,_rawList.length as double, FindMaxValue()),
              ),
              RawSet()
            ],
          ),

        ),

      );
  }
}
