// restful response
// void RestApi_Get() async{
//   http.Response response = await http.get(
//       Uri.encodeFull('http://url'),
//       headers: {"Accept": ""});
//   Map<String, dynamic> responseBody = jsonDecode(response.body);
//   print(response.body);
//   print(responseBody["restapi"]);
//
//   JsonObject jsonObject = JsonObject.fromJson(responseBody);
//   print(jsonObject.success);
// }
// class JsonObject {
//   final String success;
//
//   JsonObject({this.success});
//
//   factory JsonObject.fromJson(Map<String, dynamic> json) {
//     return JsonObject(success: json['success'] as String);
//   }
// }

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;



class TagList{
  List<tag_listTodo>? tag_list;
  TagList(this.tag_list);

  factory TagList.fromJson(String jsonString){
    List<dynamic> listFromJson = json.decode(jsonString);
    //print(jsonString);
    /* 여기부분 수정 */
    List<tag_listTodo> Tag_list = <tag_listTodo>[];
    Tag_list = listFromJson.map((e) => tag_listTodo.fromJson(e)).toList();

    return TagList(Tag_list);
  }
}

class tag_listTodo{
   final int idx;
   final String? eq;
   final String tag;
   final String addr;
   final String? comment;
   final double value;
   final String datatime;
   final double vmin;
   final double vmax;
   final double vsum;
   final int vcnt;
   final double vavg;
   final double scale;
   final double offset;
   final double alarm_hh;
   final double alarm_h;
   final double alarm_l;
   final double alarm_ll;
   final String? alarm_result;
   final String? explain;
   final String? unit;
   final int? UnitID;
   final String Host;
   final String Port;
   final String CommSetting;
   final int CommTimeOutSec;
   final String SaveMode;
   final int SaveInterval;

  tag_listTodo({required this.idx,required this.eq,required this.tag,required this.addr,required this.comment,required this.value,required this.datatime,required this.vmin,
  required this.vmax,required this.vsum,required this.vcnt,required this.vavg,required this.scale,required this.offset,required this.alarm_hh,required this.alarm_h,
  required this.alarm_l,required this.alarm_ll,required this.alarm_result,required this.explain,required this.unit,required this.UnitID,required this.Host,
    required this.Port,required this.CommSetting,required this.CommTimeOutSec,required this.SaveMode,required this.SaveInterval});

  factory tag_listTodo.fromJson(Map<String, dynamic> json){
    return tag_listTodo(
        idx: json['idx'],
        eq: json['설비'] ?? '',
        tag: json['태그'] ?? '',
        addr: json['addr'] ?? '',
        comment: json['comment'] ?? '',
        value: json['value'],
        datatime: json['datatime'],
        vmin: json['vmin'],
        vmax: json['vmax'],
        vsum: json['vsum'],
        vcnt: json['vcnt'],
        vavg: json['vavg'],
        scale: json['scale'],
        offset: json['offset'],
        alarm_hh: json['alarm_hh'],
        alarm_h: json['alarm_h'],
        alarm_l: json['alarm_l'],
        alarm_ll: json['alarm_ll'],
        alarm_result: json['alarm_result'] ?? '',
        explain: json['설명'] ?? '',
        unit: json['단위'] ?? '',
        UnitID: json['UnitID'],
        Host: json['Host'] ?? '',
        Port: json['Port'] ?? '',
        CommSetting: json['CommSetting'] ?? '',
        CommTimeOutSec: json['CommTimeOutSec'],
        SaveMode: json['SaveMode'] ?? '',
        SaveInterval: json['SaveInterval']
    );
  }
}

class rawList{
  final List<raw_ListTodo>? raw_list;
  rawList(this.raw_list);

  factory rawList.fromJson(String jsonString){
    List<dynamic> listFromJson = json.decode(jsonString);

    /* 여기부분 수정 */
    List<raw_ListTodo> raw_list = <raw_ListTodo>[];
    raw_list = listFromJson.map((e) => raw_ListTodo.fromJson(e)).toList();

    return rawList(raw_list);
  }
}

class raw_ListTodo{
  final int idx;
  final String? eq;
  final String? tag;
  final String datatime;
  final double value;
  final String? ext;
  final int kind;

  raw_ListTodo({required this.idx,required this.eq,required this.tag,required this.datatime,required this.value,required this.ext,required this.kind});

  factory raw_ListTodo.fromJson(Map<String, dynamic> json){
    return raw_ListTodo(
        idx: json['idx'],
        eq: json['eq'] ?? '',
        tag: json['tag'] ?? '',
        datatime: json['datatime'] ?? '',
        value: json['value'] ?? 0,
        ext: json['ext'] ?? '',
        kind: json['kind'] ?? 0
    );
  }
}

class mainUIList{
  final String tag;
  final double value;
  final String datatime;
  mainUIList(this.tag,this.value,this.datatime);
}
